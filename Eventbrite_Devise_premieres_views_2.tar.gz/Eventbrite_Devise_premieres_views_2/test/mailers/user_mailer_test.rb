require 'test_helper'

class UserTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
