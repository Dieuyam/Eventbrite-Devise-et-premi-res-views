# Preview all emails at http://localhost:3000/rails/mailers/user_maile_mailer
class UserMaileMailerPreview < ActionMailer::Preview

end
