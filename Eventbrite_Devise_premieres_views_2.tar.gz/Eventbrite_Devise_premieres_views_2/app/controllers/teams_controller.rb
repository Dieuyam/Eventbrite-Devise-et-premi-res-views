class TeamsController < ApplicationController
end
