class ContactsController < ApplicationController
end
